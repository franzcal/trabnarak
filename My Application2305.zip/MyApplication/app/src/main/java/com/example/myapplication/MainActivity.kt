package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.AdapterObra
import com.example.myapplication.model.Obra
import com.google.firebase.firestore.FirebaseFirestore



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val recyclerviewObras = findViewById<RecyclerView>(R.id.recyclerview_obras)
        recyclerviewObras.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        recyclerviewObras.setHasFixedSize(true)

        val db = FirebaseFirestore.getInstance()
        val catalogoRef = db.collection("teste")
        val listaObras:  MutableList<Obra> = mutableListOf()
        val adapterObra = AdapterObra(this, listaObras)
        recyclerviewObras.adapter = adapterObra

        val buttonLogin = findViewById<Button>(R.id.buttonLogin)
        val mostrarBotaoAdicionar = intent.getBooleanExtra("mostrarBotaoAdicionar", false)
        val buttonAdd = findViewById<Button>(R.id.buttonAdd)


        if (mostrarBotaoAdicionar) {
            buttonAdd.visibility = View.VISIBLE
        } else {
            buttonAdd.visibility = View.INVISIBLE
        }

        buttonAdd.setOnClickListener(){
            val telaAddObra = Intent(this, AddObra::class.java)
            startActivity(telaAddObra)
        }

        buttonLogin.setOnClickListener(){
            val segundaTela = Intent(this, Login::class.java)
            startActivity(segundaTela)
        }

        catalogoRef.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val nome = document.getString("nome")
                    val descricao = document.getString("descricao")
                    val img = document.getString("imagem")

                    val obra = Obra(img, nome, descricao)

                    listaObras.add(obra)
                }

                adapterObra.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.e("MainActivity", "Erro ao obter documentos: ", exception)

                Toast.makeText(this@MainActivity, "Erro ao obter obras: ${exception.message}", Toast.LENGTH_SHORT).show()
            }



    }
}