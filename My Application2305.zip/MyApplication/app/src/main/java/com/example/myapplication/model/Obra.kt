package com.example.myapplication.model

data class Obra(

    val foto: String?,
    val nome: String?,
    val descricao: String?,
)